"""
.. module:: nctime.axis
.. moduleauthor:: Guillaume Levavasseur <glipsl@ipsl.jussieu.fr>

"""