"""
.. module:: nctime.overlap
.. moduleauthor:: Guillaume Levavasseur <glipsl@ipsl.jussieu.fr>

"""