******
nctime
******

`See documentation here <http://prodiguer.github.io/nctime/>`_
